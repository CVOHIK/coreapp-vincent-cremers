﻿using System;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Buisiness;
using Buisiness.Interfaces;

namespace Shop
{
    public class CustomersController : Controller
    {

        private readonly ICustomerService _customerService;

        public CustomersController(ICustomerService customerService)
        {
            _customerService = customerService;
        }

        // GET: Customers
        public async Task<IActionResult> Index()
        {
            return View(await _customerService.GetAllAsync());
        }

        // GET: Customers/Details/5
        public async Task<IActionResult> Details(string id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var customer = await _customerService.GetByIdAsync(id);
            if (customer == null)
            {
                return NotFound();
            }

            return View(customer);
        }

        // GET: Customers/Create
        public IActionResult Create()
        {
            return View();
        }

        // POST: Customers/Create
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create([Bind("Id,Name,FirstName")] Customer customer)
        {
            if (ModelState.IsValid)
            {
                await _customerService.AddCustomerAsync(customer);
                return RedirectToAction(nameof(Index));
            }
            return View(customer);  
        }

        // GET: Customers/Edit/5
        public async Task<IActionResult> Edit(string id)
        {
            if (id == null)
            {
                return NotFound();
            }
            var customer = new Customer();
            customer = await _customerService.GetByIdAsync(id);

            if (customer == null)
            {
                return NotFound();
            }

            return View(customer);
        }

        // POST: Customers/Edit/5
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(String id, [Bind("Id,Name,FirstName,Email")] Customer customer)
        {
            if (!id.Equals(customer.Id))
            {
                return NotFound();
            }

            if (ModelState.IsValid)
            {

                    Customer NewCustomer = await _customerService.GetByIdAsync(customer.Id);
                    NewCustomer.Email = customer.Email;
                    NewCustomer.UserName = customer.Email;
                    NewCustomer.FirstName = customer.FirstName;
                    NewCustomer.Name = customer.Name;
                    await _customerService.updateUserAsync(NewCustomer);


                return RedirectToAction(nameof(Index));
            }
            return View(customer);
        }

        // GET: Customers/Delete/5
        public async Task<IActionResult> Delete(string id)
        {
            if (id == null)
            {
                return NotFound();
            }


            var customer = await _customerService.GetByIdAsync(id);

            if (customer == null)
            {
                return NotFound();
            }

            return View(customer);
        }

        // POST: Customers/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(string id)
        {
            try
            {
                var customer = await _customerService.GetByIdAsync(id);
                await _customerService.DeleteUserAsync(customer);
                return RedirectToAction(nameof(Index));
            }
            catch (Exception ex)
            {


                return RedirectToAction("ErrorMessage", "Main", new { message=ex.InnerException.Message, returnController = "Customers", returnAction="Index"});

            }

        }

        private bool CustomerExists(string id)
        {
            bool customerExists = _customerService.CustomerExist(id);
            return customerExists;
        }
    }
}
