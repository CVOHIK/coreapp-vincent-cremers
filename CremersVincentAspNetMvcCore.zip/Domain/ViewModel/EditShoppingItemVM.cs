﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Buisiness;

namespace Buisiness.ViewModel
{
    public class EditShoppingItemVM
    {
        public int ShoppingBagId { get; set; }
        public ShoppingItem ShoppingItem { get; set; }
        public String ProductName { get; set; }


    }
}
