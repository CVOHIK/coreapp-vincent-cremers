﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Buisiness.Enum
{
    public enum Roles
    {
        User,
        Admin

    }
}
