﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Buisiness.Interfaces
{
    public interface IDiscount
    {
        Double Percentage(int NrOfItems);
    }
}
